if (collision_circle(x,y,100,player_obj,false,true)) and keyboard_check(ord("E"))
{
 player_obj.swinging = true
}