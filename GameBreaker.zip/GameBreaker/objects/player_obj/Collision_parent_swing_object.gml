anchor_x = other.x;
anchor_y = other.y;
rope_length = point_distance(x, y, anchor_x, anchor_y);
swing_angle = point_direction(anchor_x, anchor_y, x, y) * (pi / 180);
angular_velocity = 0; 

keyboard_check(ord("E"))
{
swinging = true
}