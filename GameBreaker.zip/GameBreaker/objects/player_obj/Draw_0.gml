draw_self();
if (state == "swinging")
{
    draw_line_width(anchor_x, anchor_y, x, y, 2);
}