draw_self();
if (state == "swinging")
{
    draw_line_width_colour(anchor_x, anchor_y, x, y, 2, c_maroon, c_maroon );
}    