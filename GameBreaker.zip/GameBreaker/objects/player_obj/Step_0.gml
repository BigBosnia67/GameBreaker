if state == "normale"
{
//player input
if (swinging = false)
{
key_left = keyboard_check(ord("A")) and alive = true;
key_right = keyboard_check(ord("D")) and alive = true;
key_jump = keyboard_check_pressed(vk_space) and alive = true;
if (keyboard_check_pressed(ord("E")) && alive == true)
{
    var _target = instance_nearest(x, y, parent_swing_object); 
    if (_target != noone && point_distance(x, y, _target.x, _target.y) <= swing_range)
    {
        swinging = true;
        state = "swinging";
        swing_blend = 0;
        anchor_x = _target.x;
        anchor_y = _target.y;
        rope_length = clamp(point_distance(anchor_x, anchor_y, x, y), 30, 300);
        
        var _dir = point_direction(anchor_x, anchor_y, x, y);
        swing_angle = degtorad(angle_difference(_dir, 270));
        
        var _tangent_dir = _dir + 90;
        var _tangent_speed = (hsp * lengthdir_x(1, _tangent_dir)) + (vsp * lengthdir_y(1, _tangent_dir));
        angular_velocity = _tangent_speed / rope_length;
    }
}
if alive = true
{
//calculate movement
var move = key_right - key_left;

if (vsp != 0) {
	accel = 0.5
}
if (vsp == 0) {
	accel = 0.9
}

if (move != 0) {
	hsp += move * accel;
	hsp = clamp(hsp, -walksp, walksp);
} else {
	if (hsp > 0) hsp = max(0, hsp - fric);
	if (hsp < 0) hsp = min(0, hsp + fric);
}	
var touching_left = place_meeting(x - 1, y, parent_platform_obj) || place_meeting(x - 1, y, wall_obj);
var touching_right = place_meeting(x + 1, y, parent_platform_obj) || place_meeting(x + 1, y, wall_obj);
touching_no = !(touching_left || touching_right);
vsp = vsp + grv; 

//wall jump
if (place_meeting(x+hsp,y,parent_wall_obj)) and (vsp > 0)
{
vsp = vsp/1.1
}

if (place_meeting(x+hsp,y,parent_wall_obj)) and not (place_meeting(x,y+vsp,obj_ground)) and (vsp > 0.3 or vsp <-0.3) and (key_jump)
{
	vsp = -7;
	hsp = -8 * move;
}

if (place_meeting(x,y+1,parent_platform_obj))  and (key_jump)
{
		vsp = -7;
	
}
var on_deathwall_left  = place_meeting(x - 1, y,parent_damage_object);
var on_deathwall_right = place_meeting(x + 1, y,parent_damage_object);
var on_deathwall_up    = place_meeting(x, y - 1,parent_damage_object);
var on_deathwall_down  = place_meeting(x, y + 1,parent_damage_object);

if (on_deathwall_left || on_deathwall_right || on_deathwall_up || on_deathwall_down) {
    is_deathtouching = true;
} else {
    is_deathtouching = false;
}
if is_deathtouching = true
{
alive = false;
swinging = false;
state = "normale";
}
else
{
alive = true
}
//horizontal collision
if (place_meeting(x+hsp,y,parent_platform_obj))
{	
	while (!place_meeting(x+sign(hsp),y,parent_platform_obj))
	{
		x = x + sign(hsp);	
	}
	wall_slide = true;
	hsp = 0;
}	

x = x + hsp;


//vertical collision
if (place_meeting(x,y+vsp,parent_platform_obj))
{
	while (!place_meeting(x,y+sign(vsp),parent_platform_obj))
	{
		y = y + sign(vsp);
	}
	wall_slide = false;
	vsp = 0;
}	

y = y + vsp;


//sprite
if (hsp != 0 and vsp = 0 and wall_slide = false){
	sprite_index = player_right_running_1;
}
else if (vsp != 0 and touching_no = true){
	sprite_index = player_right_jump_2;
}
else if (wall_slide = true and touching_no = false){
	sprite_index = player_right_walljump_1;
}
else {
	sprite_index = player_right_idle_1;
}
}
if (alive = false)
{	
	sprite_index = player_death
}
if (image_index+image_speed >= image_number) and sprite_index = player_death
{ 
	instance_destroy(player_obj);
}
}
}
if (swinging == true && alive == true)
{
var on_deathwall_left  = place_meeting(x - 1, y,parent_damage_object);
var on_deathwall_right = place_meeting(x + 1, y,parent_damage_object);
var on_deathwall_up    = place_meeting(x, y - 1,parent_damage_object);
var on_deathwall_down  = place_meeting(x, y + 1,parent_damage_object);

if (on_deathwall_left || on_deathwall_right || on_deathwall_up || on_deathwall_down) {
    is_deathtouching = true;
} else {
    is_deathtouching = false;
}
if is_deathtouching = true
{
alive = false;
swinging = false;
state = "normale";
}
else
{
alive = true
}
    var _max_angle = pi / 2; 
    var _swing_input = keyboard_check(ord("D")) - keyboard_check(ord("A"));
    var _climb_input = keyboard_check(vk_down) - keyboard_check(vk_up);
    var _new_length = clamp(rope_length + (_climb_input * 2), 30, 300);
    var _check_dir = 270 + radtodeg(swing_angle);
    var _climb_x = anchor_x + lengthdir_x(_new_length, _check_dir);
    var _climb_y = anchor_y + lengthdir_y(_new_length, _check_dir);
    
    if (!place_meeting(_climb_x, _climb_y, parent_platform_obj))
    {
        rope_length = _new_length;
    }

    var _substeps = 4;
    var _dt = 1 / _substeps;
    var _hit_wall = false;
    
    repeat (_substeps)
    {
        var _moving_up = (sign(angular_velocity) == sign(swing_angle)) && (abs(swing_angle) > 0);
        var _height_ratio = clamp(abs(swing_angle) / _max_angle, 0, 1);

        var _push_power = power(max(0, 1 - _height_ratio), 2);
        angular_velocity += (((_swing_input * 0.14) / rope_length) * _push_power) * _dt;

        var _accel = -(gravity_pull / rope_length) * sin(swing_angle);
        angular_velocity += _accel * _dt;
        
        if (_moving_up && _height_ratio > 0.65)
        {
            var _brake_strength = (_height_ratio - 0.65) / 0.35;
            angular_velocity *= power(1 - (0.08 * _brake_strength), _dt);
        }

        angular_velocity *= power(0.994, _dt);
        
        var _next_angle = swing_angle + (angular_velocity * _dt);
        var _test_dir = 270 + radtodeg(_next_angle);
        var _test_x = anchor_x + lengthdir_x(rope_length, _test_dir);
        var _test_y = anchor_y + lengthdir_y(rope_length, _test_dir);
        
        if (!place_meeting(_test_x, _test_y, parent_platform_obj))
        {
            swing_angle = _next_angle;
        }
        else
        {
            angular_velocity = 0;
            _hit_wall = true;
            break;
        }
    }

    var _rope_dir = 270 + radtodeg(swing_angle);
    var _target_x = anchor_x + lengthdir_x(rope_length, _rope_dir);
    var _target_y = anchor_y + lengthdir_y(rope_length, _rope_dir);
    
    swing_blend = min(1, swing_blend + 0.25);
    var _blend_x = lerp(x, _target_x, swing_blend);
    var _blend_y = lerp(y, _target_y, swing_blend);
    
    if (!place_meeting(_blend_x, _blend_y, parent_platform_obj))
    {
        x = _blend_x;
        y = _blend_y;
    }
    else
    {
        swing_blend = 1;
        angular_velocity = 0;
    }

    if (keyboard_check_pressed(vk_space))
    {
        swinging = false;
        state = "normale";
        
        hsp = 2;
        vsp = -6;
		
    }
}
if (hsp < 0) image_xscale = -1;
if (hsp > 0) image_xscale = 1;
